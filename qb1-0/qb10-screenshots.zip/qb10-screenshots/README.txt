QB1-0 - the end is inevitable; the question is how long can you survive?


QB1-0 is a 2D arcade space shooter game for iOS devices where you can't slow down, you can't stop shooting and, ultimately, you can't survive. Playing as a lone pilot, trapped in space and facing endless waves of enemies, how long before you're overwhelmed?

The gameplay is a nod to past classics with short, intense games, neo-retro vector graphics and a control system uniquely tailored to touch screen devices.

Features such as always on auto-fire and auto-thrust help deliver a more intense, frantic experience, especially as the difficulty increases. The addition of being able to boost the ship using a simple flick gesture adds depth to the gameplay without over-complicating the controls.

The wave difficulty ramps up quickly to encourage a just-one-more-go feeling when it's game over.

The name QB1-0 is derived from 'cubewano' - a classical low-eccentricity Kuiper belt object. Yes, space rocks.


Availability: now
Price: Tier 1 (0.99c)
Platform: iPhone / iPad


Media

	http://qb1-0.canfactory.com/qb10-screenshots.zip
	http://youtu.be/sif7dsV8yvo

Download

	https://itunes.apple.com/us/app/qb1-0/id580175669?ls=1&mt=8

	(Promo codes available on request)

Links

	http://qb1-0.canfactory.com/
	http://qb1-0.canfactory.com/press.html
	

App Store Blurb

Something strange is stirring in the Kuiper belt ...

A lone pilot cut-off from home is trapped in a strangely familiar, toroidal pocket of two-dimensional space.

Navigating an ever-growing shower of rocky planetoids the situation is growing desperate as numerous strange and aggressive space-dwelling entities attack.

Only fast reactions and a large slice of luck will ensure your survival in a fast-paced, retro arcade shooter.


Reviews

"... a stylish frenetic arcade shooter with responsive controls, that fills the screen with particles and enemies and bullets" 

Indie Game Enthusiast - http://indiegameenthusiast.blogspot.co.uk/2014/07/ios-spotlight-80-qb1-0.html


App Store reviews:

"...the game is beautiful and captures the essence of vector-based arcade games of the 80s. Easily worth $0.99! Well done!.."

"Nice graphics, smooth play."


About Can Factory

Can Factory is a bespoke software development agency based in London, UK, specialising in high-traffic websites, back-office systems and mobile apps.

Whilst game development isn't Can Factory's core business we encourage developers to engage in developing their own products - QB1-0 was produced as a result of this.

	http://canfactory.com/




Any questions please don't hesitate to contact me:
	joe@canfactory.com


Thank you for your interest and we hope you enjoy playing QB1-0!
